package model;

import java.util.LinkedList;
import java.util.List;

public class LayoutAlgorithm {
    private Node root = new Node();
    private double treeHeight;
    private double windowHeight;
    private double windowWidth;
    private LinkedList<Node>  allNodesFromTree;
    private int nodesInTree;
    private int leavesInTree;
    public LayoutAlgorithm(double windowHeight, double windowWidth, Node root)
    {
        this.windowHeight = windowHeight;
        this.windowWidth = windowWidth;
        this.root = root;
    }
    public void setRoot(Node tree) {
        this.root = tree;
    }
    public Node getRoot() {
        return root;
    }

    public void setTreeHeight(double height) {
        this.treeHeight = height;
    }

    public double getTreeHeight() {
        return treeHeight;
    }

    public double getWindowHeight() {
        return windowHeight;
    }

    public double getWindowWidth() {
        return windowWidth;
    }

    public void setWindowHeight(double windowHeight) {
        this.windowHeight = windowHeight;
    }

    public void setWindowWidth(double windowWidth) {
        this.windowWidth = windowWidth;
    }
   public FXEdges[] treeInImage()
    {
        Node root = this.root;
        //Es gibt eine Kante weniger im Baum als Knoten
        int count = 0;
        int leaveCount =0;
        this.calcPosForTree(this.root);
        this.allNodesFromTree = null;
        this.analyzeTree(this.root);
        FXEdges[] edges = new FXEdges[this.allNodesFromTree.size()];
        LinkedList<Node> curr = this.allNodesFromTree;
        while(!curr.isEmpty())
        {
            Node currNode = curr.getFirst();
            FXEdges ed = new FXEdges();
            ed.setChild(currNode);
            if(currNode.getParent() != null) {
                ed.setParent(currNode.getParent());
            }
            ed.setDimensions(currNode.getStartX(), currNode.getStartY(), currNode.getEndX(), currNode.getEndY());
            edges[count] = ed;
            curr = new LinkedList<Node>(curr.subList(1, curr.size()));
            count++;
        }
        return edges;
    }
    public void analyzeTree(Node root)
    {
        if(root != null && !root.isEmpty()) {
            if(this.allNodesFromTree==null)
            {
                this.allNodesFromTree = new LinkedList<Node>(List.of(root));
            }
            else
            {
                this.allNodesFromTree.add(root);
            }
                this.nodesInTree++;
                if (root.isLeaf()) {
                    this.leavesInTree++;
                } else {
                    analyzeTree(root.getLeftNode());
                    analyzeTree(root.getRightNode());
                }
        }
    }
    public int leavesOnLeftSide(Node leave)
    {
        //Knoten im rechten Teilbaum ?
        //Nein -> im linken Weitersuchen
        //Ja -> Blätter aus linkem Teilbaum dazuaddieren, Weitersuchen im rechten Baum
        int count =0;
        Node curr = this.root;
        if(!leave.isLeaf())
        {
            return -1;
        }
        while(!curr.isLeaf())
        {
            if(curr.isInTree(leave,curr))
            {
                if(curr.getLeftNode().isInTree(leave,curr.getLeftNode()))
                {
                    curr = curr.getLeftNode();
                }
                else if(curr.getRightNode().isInTree(leave,curr.getRightNode()))
                {
                    count = count + curr.countLeaves(curr.getLeftNode());
                    curr = curr.getRightNode();
                }
            }
        }
        return count;
    }
    //to DO!!!
    public void calcPosForTree(Node tree)
    {
        if(tree.isEmpty() ||tree == null)
        {
            return;
        }
        else if(tree.isLeaf())
        {
                calcPosForNode(tree);
        }
        else {
            calcPosForTree(tree.getLeftNode());
            calcPosForTree(tree.getRightNode());
            calcPosForNode(tree);
        }
    }
    public void calcPosForNode(Node node)
    {
        double startX =0;
        double endX = 0;
        double startY=0;
        double endY=0;
        //Abstand zwischen zwei Blättern im Bild
        double distBetLeaves = this.windowWidth/(this.leavesInTree+1);
        //Hier muss Abstand nach oben/unten im Fenster angepasst werden
        double treeHeightInPix = this.windowHeight/(root.getHeight()+20);
        if(node.isEmpty()||node == null)
        {
            return;
        }
        else if(node.isLeaf())
        {
            startX = distBetLeaves + (this.leavesOnLeftSide(node) * distBetLeaves);
            startY = this.windowHeight - (20 + (node.getHeight() * treeHeightInPix));
            endY = this.windowHeight - ((node.getParent().getHeight() * treeHeightInPix) + 20);
            if (node.getParent().getLeftNode().getHead().equals(node.getHead())) {
                endX = startX + (distBetLeaves / 2);
            } else {
                endX = startX - (distBetLeaves / 2);
            }
            node.setEndX(endX);
            node.setPosCalculated(true);
        }
        else if(node.getParent() != null)
        {
            double leftNodeStartX = node.getLeftNode().getStartX();
            double rightNodeStartX = node.getRightNode().getStartX();
            startX = leftNodeStartX + ((rightNodeStartX - leftNodeStartX)/2);
            node.getLeftNode().setEndX(startX);
            node.getRightNode().setEndX(startX);
            startY = this.windowHeight - (20 + (node.getHeight()* treeHeightInPix));
            endY = this.windowHeight - ((node.getParent().getHeight() * treeHeightInPix) + 20);
            node.setPosCalculated(true);
        }
       else if(node.getParent() == null)
        {
            double leftNodeStartX = node.getLeftNode().getStartX();
            double rightNodeStartX = node.getRightNode().getStartX();
            startX = leftNodeStartX + ((rightNodeStartX-leftNodeStartX)/2);
            node.getLeftNode().setEndX(startX);
            node.getRightNode().setEndX(startX);
            endX = startX;
            startY =this.windowHeight -  ((treeHeightInPix * node.getHeight()) + 20);
            endY =this.windowHeight -  (20 + startY);
            node.setEndX(endX);
            node.setPosCalculated(true);
        }
       node.setStartY(startY);
       node.setStartX(startX);
       node.setEndY(endY);
    }
    public boolean isAllPosCalculated(Node root)
    {
        if(root.isEmpty() || root == null)
        {
            return false;
        }
        else if(root.isLeaf())
        {
            return root.isPosCalculated();
        }
        else
        {
            return root.isPosCalculated() && isAllPosCalculated(root.getLeftNode()) && isAllPosCalculated(root.getRightNode());
        }
    }
}
