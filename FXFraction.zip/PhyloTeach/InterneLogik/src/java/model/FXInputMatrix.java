package model;

import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.text.Font;

public class FXInputMatrix {

    private GridPane grid;
    private TextArea[][] textArea;
    private int taxaNum;

    private String[] taxa;
    private String input;

    public FXInputMatrix(int taxaNum) {
        this.taxaNum = taxaNum;
        this.textArea = new TextArea[this.taxaNum][this.taxaNum]; // Zeile x Spalte
        this.grid = new GridPane();
        this.taxa = new String[taxaNum];
    }

    public void createGridPane() {

        int fieldSize = 40; // muss min. 40 sein da sonst TextArea nicht passt
        int letterIdx = 65; // Taxa Beschriftung mit ASCII-Codierung (65-90)
        int taxaIdx = 0;

        for (int i = 0; i <= taxaNum; i++) { // i ist Zeilenindex

            // jedes Feld fieldSize x fieldSize groß
            ColumnConstraints column = new ColumnConstraints(fieldSize);
            RowConstraints row = new RowConstraints(fieldSize);
            grid.getColumnConstraints().add(column);
            grid.getRowConstraints().add(row);

            if (i == 0) continue;

            // füge Taxa hinzu
            Label taxaCol = new Label(" " + Character.toString(letterIdx) + " ");
            taxaCol.setFont(new Font("Arial", 25));

            Label taxaRow = new Label(" " + Character.toString(letterIdx) + " ");
            taxaRow.setFont(new Font("Arial", 25));

            grid.add(taxaCol, i, 0); // 1. Zahl: Spalte, 2. Zahl: Zeile
            grid.add(taxaRow, 0, i); // 1. Zahl: Spalte, 2. Zahl: Zeile

            // speichert Taxabeschriftung
            taxa[taxaIdx] = Character.toString(letterIdx);

            taxaIdx++;
            letterIdx++;
        }

        // erstelle TextArea zur Eingabe
        int indexI = 0;
        int indexJ;

        for (int i = 1; i <= taxaNum; i++) {
            indexJ = 0;

            for (int j = 1; j <= taxaNum; j++) {
                textArea[indexI][indexJ] = new TextArea();
                grid.add(textArea[indexI][indexJ], j, i); // zuerst j dann i -> damit in text zeile x spalte aufgefüllt wird
                indexJ++;
            }
            indexI++;
        }

        grid.setGridLinesVisible(true);
    }

    public void processInput() {

        StringBuilder input = new StringBuilder();
        input.append(',');

        // 1. Zeile mit Taxa beschriftung
        for (int i = 0; i < this.taxa.length - 1; i++) {
            input.append(taxa[i]).append(",");
        }
        // letztes Zeichen
        input.append(taxa[this.taxa.length - 1]).append("\n");

        // restliche Zeilen
        for (int i = 0; i < taxaNum; i++) {

            input.append(taxa[i]).append(",");

            for (int j = 0; j < taxaNum; j++) {

                if (j == taxaNum - 1) {  // letzte Zahl in Zeile
                    input.append(this.textArea[i][j].getText()).append("\n");
                } else {
                    input.append(this.textArea[i][j].getText()).append(",");
                }
            }
        }
        this.input = input.toString();
    }

    public String getInput() { return this.input; }

    public GridPane getGrid() {
        return this.grid;
    }
}
