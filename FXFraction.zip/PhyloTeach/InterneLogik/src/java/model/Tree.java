package model;

import javafx.scene.layout.AnchorPane;

import java.util.LinkedList;

public class Tree {

    private Node root;
    //noch richtige Datentypen ändern
    private LinkedList<String> matrixList;
    private LinkedList<AnchorPane> calcList;
    private LinkedList<String> treeList;

    public Tree(String[] taxa, double[][] distanceMatrix) {
        UPGMA up = new UPGMA();
        this.root = up.algorithm(taxa, distanceMatrix);
        this.matrixList = up.getMatrixList();
        this.calcList = up.getCalcList();
        this.treeList = up.getTreeList();
    }

    public Node getRoot() {
        return root;
    }

    public LinkedList<String> getMatrixList() {
        return matrixList;
    }

    public LinkedList<AnchorPane> getCalcList() {
        return calcList;
    }

    public LinkedList<String> getTreeList() {
        return treeList;
    }


}
