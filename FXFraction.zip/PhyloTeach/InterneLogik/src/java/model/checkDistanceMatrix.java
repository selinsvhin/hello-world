package model;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Arrays;
import java.util.LinkedList;

/**
 * überprüft ob gegebene Distanz Matrix korrekt ist
 * checkDistanceMatrix.check == "true" -> korrekt
 * checkDistanceMatrix.check == "Errormeldung:" -> falsch und Errormeldung an Benutzer weitergeben
 */
public class checkDistanceMatrix {

    private double[][] distanceMatrix;
    private String[] taxa;
    private String check;

    private String path;
    private String[] inputMatrix; // in jedem Feld eine Zeile

    /**
     * Wenn isPath == true wurde ein Dateipfad eingegeben, sonst wurde die Matrix in das Feld eingetragen
     */
    public checkDistanceMatrix(String input, boolean isPath) throws IOException {

        if (input.equals("")) {
            this.check = "Error: Fehlende Eingabe!";

        } else {
            if (isPath) {
                this.path = input;

            } else {
                this.inputMatrix = input.split("\n");
                this.taxa = inputMatrix[0].substring(1).split(",");
            }

            this.check = checkFormatQuadraticTaxa(isPath);
        }
    }

    /**
     * überprüft Matrix auf: csv Format, einheitliche Taxabeschriftung, quadratisch, positive Distanzen, Diagonal nur 0en enthält, Distanzen an Diagonale gespiegelt sind
     *
     * @return "true" wenn alles richtig, sonst "Error: 'Errorbeschreibung'"
     */
    public String checkFormatQuadraticTaxa(boolean isPath) throws IOException {

        LinkedList<String> isCSV;        // speichert einzelne Zeilen als Listenelemente
        LinkedList<String> sameTaxa;

        //überprüfen ob richtiges csv-Format
        if (isPath) {

            // überprüfen ob Pfad auf .csv endet
            if (this.path.length() >= 5) {
                String end = this.path.substring(this.path.length() - 4);
                if (!end.equals(".csv")) {
                    return "Error: Keine csv Datei!";
                }
            } else {
                return "Error: Keine csv Datei!";
            }

            isCSV = new LinkedList<>(Files.readAllLines(Path.of(this.path)));

            // löscht Leerzeichen in erster Zeile
            StringBuilder temp = new StringBuilder(isCSV.get(0));
            temp.deleteCharAt(0);
            isCSV.set(0, temp.toString());

            // speichert Matrix in inputMatrix
            String[] temp1 = new String[isCSV.size()];
            for (int i = 0; i < isCSV.size(); i++) {
                temp1[i] = isCSV.get(i);
            }
            this.inputMatrix = temp1;

        } else {
            isCSV = new LinkedList<>(Arrays.stream(this.inputMatrix).toList());
        }

        sameTaxa = (LinkedList<String>) isCSV.clone(); // für spätere Überprüfung ob korrekte Taxabeschriftung
        sameTaxa.pollFirst();
        this.taxa = inputMatrix[0].substring(1).split(","); // ordnet Taxa zu

        String tempCheck;

        // überprüfen ob jedes Feld mit Zahl befüllt wurde
        tempCheck = correctInput();
        if (!tempCheck.equals("true")) return tempCheck;

        // überprüft ob Kommas richtig und quadratisch
        tempCheck = correctCommas(isCSV);
        if (!tempCheck.equals("true")) return tempCheck;

        // Überprüft auf korrekte Taxa Beschriftung
        tempCheck = correctTaxa(sameTaxa);
        if (!tempCheck.equals("true")) return tempCheck;

        assignMatrix(isPath);

        // Überprüft ob Diagonale 0, Distanzen positiv, Matrix symmetrisch
        tempCheck = correctNumbers();
        if (!tempCheck.equals("true")) return tempCheck;

        return ultrametric(); //ultrametric überprüfen
    }

    /**
     * überprüft ob es nur zahlen als Input gibt und ob in jedem Feld eine Zahl steht
     * @return "true" wenn korrekt, sonst "Errormeldung"
     */
    public String correctInput() {

        for(int i = 1; i < this.inputMatrix.length; i++) {

            String[] row = inputMatrix[i].split(",");

            // wenn gar nichts befüllz wurde
            if(row.length < taxa.length)  return "Error: Es wurden nicht alle Felder befüllt!";

            for(int j = 1; j < row.length; j++) {

                if(row[j].equals("")) {
                    return "Error: Es wurden nicht alle Felder befüllt!";
                } else {

                    try{
                        Double.parseDouble(row[j]);
                    } catch(NumberFormatException e) {
                        return "Error: Als Eingabe sind nur Zahlen erlaubt!";
                    }

                }
            }
        }
        return "true";
    }

    /**
     * Überprüft ob die Kommas richtig gesetzt sind und damit auch ob die Zeilen alle gleich lang sind und ob die Matrix quadratisch ist
     *
     * @return "true" wenn alles passt, sonst "Errormeldung"
     */
    public String correctCommas(LinkedList<String> isCSV) {

        //Links oben muss ein Komma stehen
        String firstRow = isCSV.getFirst();
        if (firstRow.charAt(0) != ',') {
            return "Error: Kein valides csv-Format, die erste Zeile muss mit einem Komma beginnen!";
        }
        // Anzahl Kommas muss in jeder Zeile gleich sein (Zeilen gleich lang), erstelle Referenz aus erster Zeile
        int reference = 0;
        for (int i = 0; i < firstRow.length(); i++) {
            if (firstRow.charAt(i) == ',') {
                reference++;
            }
        }
        // vergleiche, ob Anzahl der Kommas in allen anderen Zeilen gleich
        while (!isCSV.isEmpty()) {
            firstRow = isCSV.getFirst();
            isCSV.pollFirst();  // entfernt erstes Listenelement
            int commas = 0;
            for (int i = 0; i < firstRow.length(); i++) {
                if (firstRow.charAt(i) == ',') {
                    commas++;
                }
            }
            if (reference != commas) {
                return "Error: Die Zeilen sind nicht gleich lang (Anzahl der Kommas ist unterschiedlich)!";
            }
        }

        // Quadratisch: vergleiche Kommas in erster Zeile (Anzahl Spalten) und überprüfe, ob es genau so viele (Zeilen-1) gibt
        if (reference != (this.inputMatrix.length) - 1) {
            return "Error: Die Matrix ist nicht quadratisch!";
        }
        return "true";
    }

    /**
     * überprüft ob in erster Zeile und erster Spalte dieselben taxa stehen
     */
    public String correctTaxa(LinkedList<String> sameTaxa) {

        int index = 0; //Index des aktuellen Taxons

        //gleiche Taxa in erster Zeile wie in erster Spalte?
        while (!sameTaxa.isEmpty()) {

            String row = sameTaxa.getFirst();
            sameTaxa.pollFirst();

            StringBuilder TaxaBuilder = new StringBuilder();
            int i = 0;
            while (row.charAt(i) != ',') { // falls Taxa aus mehr als einem Buchstaben besteht
                TaxaBuilder.append(row.charAt(i));
                i++;
            }
            String temp = TaxaBuilder.toString();

            if (!temp.equals(this.taxa[index])) {
                return "Error: Die erste Spalte und die erste Zeile enthalten nicht die gleichen Taxa!";
            }
            index++;
        }
        return "true";
    }

    /**
     * Zuweisung der Distance Matrix
     */
    public void assignMatrix(boolean isPath) {

        if (isPath) {
            ReadCSV csv = new ReadCSV(this.path);
            this.distanceMatrix = csv.getDistanzmatrix();

        } else {
            File file = new File("distanceMatrix.csv");
            try {
                BufferedWriter writer = new BufferedWriter(new FileWriter(file));
                for (String str : this.inputMatrix) {
                    writer.write(str);
                    writer.newLine();
                }
                writer.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            ReadCSV csv = new ReadCSV(file.getPath());
            this.distanceMatrix = csv.getDistanzmatrix();
        }
    }

    /**
     * Überprüft ob Diagonale 0 ist, die Distanzen an der Diagonalen gespiegelt sind und positiv sind
     *
     * @return "true" wenn alles korrekt, sonst "Error: 'Errorbeschreibung'"
     */
    public String correctNumbers() {

        for (int i = 0; i < this.distanceMatrix.length; i++) {

            // Diagonale ist 0
            if (this.distanceMatrix[i][i] != 0) {
                return "Error: Die Diagonale darf nur 0en enthalten!";
            }

            for (int j = 0; j < i; j++) {
                // Zahlen >= 0
                if (this.distanceMatrix[i][j] < 0) {
                    return "Error: Die Distanzen müssen positiv sein!";
                }
                // Zahlen an der Diagonalen gespiegelt
                if (this.distanceMatrix[i][j] != this.distanceMatrix[j][i]) {
                    return "Error: Die Distanzen müssen an der Diagonalen gespiegelt sein!";
                }
            }
        }
        return "true";
    }

    /**
     * überprüft ob Matrix ultrametrisch ist also ob das erfüllt ist:
     * d(i,k) <= max{d(i,j), d(j,k)} für alle i,j,k in der Matrix
     *
     * @return 'true' wenn ultrametrisch, sonst 'Achtung die Matrix ist nicht ultrametrisch'
     */
    public String ultrametric() {

        for (int i = 0; i < distanceMatrix.length; i++) {

            for (int k = 0; k < i; k++) {

                for (int j = 0; j < distanceMatrix.length; j++) {
                    if (j == i || j == k) continue;

                    double dist = distanceMatrix[i][k];
                    double max = Math.max(distanceMatrix[i][j], distanceMatrix[j][k]);
                    if (dist > max) {
                        return "Achtung die Matrix ist nicht ultrametrisch: Der Baum wird nicht korrekt dargestellt!";
                    }
                }
            }
        }
        return "true";
    }

    public String[] getTaxa() {
        return this.taxa;
    }

    public double[][] getDistanceMatrix() {
        return this.distanceMatrix;
    }

    public String getCheck() {
        return this.check;
    }


  /*  public static void main(String[] args) throws IOException {
        String matrix = ",A,B,C,D,E,F,G\n" +
                "A,0,19,27,8,33,18,13\n" +
                "B,19,0,31,18,36,1,13\n" +
                "C,27,31,0,26,41,32,29\n" +
                "D,8,18,26,0,31,17,14\n" +
                "E,33,36,41,31,0,35,28\n" +
                "F,18,1,32,17,35,0,12\n" +
                "G,13,13,29,14,28,12,0";

        String ultrametric = ",A,B,C,D,E\n" +
                "A,0,8,8,5,3\n" +
                "B,8,0,3,8,8\n" +
                "C,8,3,0,8,8\n" +
                "D,5,8,8,0,5\n" +
                "E,3,8,8,5,0";

        checkDistanceMatrix test = new checkDistanceMatrix(ultrametric, false);
        System.out.println(test.getCheck());
    }*/

}

