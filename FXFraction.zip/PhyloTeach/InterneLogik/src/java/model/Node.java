package model;

public class Node {
    private String head = "";
    private Node leftNode = null;
    private Node rightNode = null;
    private Node parent = null;
    private Edge leftEdge = null;
    private Edge rightEdge = null;
    private boolean Empty = true;
    private double height = 0;
    private double startX = 0;
    private double startY = 0;
    private double endX = 0;
    private double endY = 0;
    private boolean posCalculated;

    public boolean isPosCalculated() {
        return posCalculated;
    }

    public void setPosCalculated(boolean posCalculated) {
        this.posCalculated = posCalculated;
    }

    public Node() {
        this.hasSomething();
    }

    public void setEndX(double endX) {
        this.endX = endX;
    }

    public double getEndX() {
        return endX;
    }

    public double getEndY() {
        return endY;
    }

    public double getStartX() {
        return startX;
    }

    public void setEndY(double endY) {
        this.endY = endY;
    }

    public double getStartY() {
        return startY;
    }

    public void setStartX(double startX) {
        this.startX = startX;
    }

    public void setStartY(double startY) {
        this.startY = startY;
    }
    public Node getLeftNode() {
        return leftNode;
    }

    public Node getRightNode() {
        return rightNode;
    }

    public Node getParent() {
        return parent;
    }

    public String getHead() {
        return head;
    }

    public void setHead(String head) {
        this.head = head;
    }

    public void setLeftNode(Node leftNode) {
        this.leftNode = leftNode;
    }

    public void setParent(Node parent) {
        this.parent = parent;
    }

    public void setRightNode(Node rightNode) {
        this.rightNode = rightNode;
    }

    public Edge getLeftEdge() {
        return leftEdge;
    }

    public Edge getRightEdge() {
        return rightEdge;
    }

    public void setLeftEdge(Edge leftEdge) {
        this.leftEdge = leftEdge;
    }

    public void setRightEdge(Edge rightEdge) {
        this.rightEdge = rightEdge;
    }

    public boolean isRoot() {
        if (this.parent == null) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isLeaf() {
        if (this.leftNode == null && this.rightNode == null) {
            return true;
        } else {
            return false;
        }
    }

    public boolean isEmpty() {
        return this.Empty;
    }

    public boolean hasSomething() {
        if (this.leftNode != null || this.rightNode != null || this.getHead().length() > 0 || this.isLeaf()) {
            this.Empty = false;
            return true;
        } else {
            return true;
        }
    }

    public double getHeight() {
        return height;
    }

    public void setHeight(double height) {
        this.height = height;
    }
    public boolean isInTree(Node x, Node search)
    {
        String head = x.getHead();
        if(x == null || search == null || this.isEmpty() || x.isEmpty() || search.isEmpty())
        {return false;}
        else if(head.equals(search.getHead()))
        {
            return true;
        }
        else if(search.isLeaf())
        {
            return false;
        }
        else {
            if(this.isInTree(x,search.getLeftNode()) || this.isInTree(x,search.getRightNode()) )
            {
                return true;
            }
            else
            {return false;}
        }
    }
    public int countLeaves(Node node)
    {
        if(node == null || node.isEmpty())
        {
            return 0;
        }
        if(node.isLeaf())
        {
            return 1;
        }
        else
        {
            return countLeaves(node.leftNode)+ countLeaves(node.rightNode);
        }
    }
}
