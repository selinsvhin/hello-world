package model;
import javafx.scene.layout.AnchorPane;

import java.util.LinkedList;

public class UPGMA {

    //TODO: zu passenden Datentypen öndern
    static private LinkedList<String> matrixList = new LinkedList<>();
    static private LinkedList<AnchorPane> calcList = new LinkedList<>();
    static private LinkedList<String> treeList = new LinkedList<>();

    public static LinkedList<String> getMatrixList() {
        return matrixList;
    }

    public static LinkedList<AnchorPane> getCalcList() {
        return calcList;
    }

    public static LinkedList<String> getTreeList() {
        return treeList;
    }

    public Node algorithm(String[] taxa, double[][] distanceMatrix) {

        //TODO @Lenny: während algorithm die Liste matrixList schrittweise mit den Matrizen befüllen, Liste muss am Ende gleich lang sein wie calcList und treeList
        //folgende Dummys müssen dann gelöscht werden
        this.matrixList.add("Matrix eins");
        this.matrixList.add("Matrix zwei");
        this.matrixList.add("Matrix drei");

        //TODO @Selin: während algorithm die Liste calcList schrittweise mit den Rechnungen befüllen, Liste muss am Ende gleich lang sein wie matrixList und treeList
        //folgende Dummys müssen dann gelöscht werden
        FXFraction frac = new FXFraction(10,20,30,40);
        frac.createCalc();
        AnchorPane pane = frac.getPane();

        this.calcList.add(pane);
        //this.calcList.add("Rechnung zwei");
        //this.calcList.add("Rechnung drei");

        //TODO @Émil: während algorithm die Liste treeList schrittweise mit den Teilbäumen befüllen, Liste muss am Ende gleich lang sein wie matrixList und calcList
        //folgende Dummys müssen dann gelöscht werden
        this.treeList.add("Baum eins");
        this.treeList.add("Baum zwei");
        this.treeList.add("Baum drei");

        String[][] cluster = new String[taxa.length][];
        //die ersten Cluster sind alle Blätter -> also die Taxen
        for (int i = 0; i < taxa.length; i++) {
            cluster[i] = new String[]{taxa[i]};
        }
        double[][] distMatrix = distanceMatrix;
        //String[][] allNodes = cluster;
        Node[] allNodes = this.allNodes(cluster);
        //hier wird eigentlicher UPGMA angewendet
        while (cluster.length > 2) {
            int[] pair = this.getSmallestDist(distMatrix);
            double d = distMatrix[pair[0]][pair[1]];
            String[] newCluster = this.newCLuster(pair, cluster);
            distMatrix = this.updateDistMatrix(cluster, distMatrix, pair);
            Node newRoot = this.createNode(cluster, pair, d / 2);
            cluster = this.setCluster(cluster, pair, newCluster);
            allNodes = this.setNewAllNodes(allNodes, newRoot);
        }
        //letzten beiden Cluster werden zusammengefügt und der Baum erstellt.
        if (cluster.length == 2) {
            int[] pair = new int[]{0, 1};
            String[] newCluster = this.newCLuster(pair, cluster);
            double d = distMatrix[pair[0]][pair[1]];
            Node newRoot = this.createNode(cluster, pair, d / 2);
            cluster = this.setCluster(cluster, pair, newCluster);
            allNodes = this.setNewAllNodes(allNodes, newRoot);
        }
        return this.createTree(allNodes);
    }

    //calculates the smallest distance
    public int[] getSmallestDist(double[][] distMatrix) {
        int[] index = {-1, -1};
        double small = Double.POSITIVE_INFINITY;
        for (int i = 0; i < distMatrix.length; i++) {
            for (int j = 0; j < distMatrix[i].length; j++) {
                if (small > distMatrix[i][j] && i != j) {
                    small = distMatrix[i][j];
                    index[0] = i;
                    index[1] = j;
                }
            }
        }
        return index;
    }

    // fügt alle neuen Cluster zu den vorherigen hinzu
    public String[][] setCluster(String[][] cluster, int[] pair, String[] newCluster) {
        String[][] safeCl = new String[cluster.length - 1][];
        int counter = 0;
        for (int i = 0; i < cluster.length; i++) {
            if (i == pair[0]) {
                safeCl[counter] = newCluster;
            } else if (pair[1] == i) {
                counter--;
            } else {
                safeCl[counter] = cluster[i];
            }
            counter++;
        }
        return safeCl;
    }

    //erstellt einen neuen Cluster aus zwei anderen
    public String[] newCLuster(int[] pair, String[][] cluster) {
        String[] newCluster = new String[cluster[pair[0]].length + cluster[pair[1]].length];
        for (int i = 0; i < newCluster.length; i++) {
            if (i < cluster[pair[0]].length) {
                newCluster[i] = cluster[pair[0]][i];
            } else {
                newCluster[i] = cluster[pair[1]][i - cluster[pair[0]].length];
            }
        }
        return newCluster;
    }

    //erstellt die neue distanz matrix, sodass ein Element weniger drinnen ist, da zwei zu einem zusammengeschweist wurden
    public double[][] updateDistMatrix(String[][] cluster, double[][] distMatrix, int[] pair) {
        double[][] safeDistMatrix = new double[distMatrix.length - 1][distMatrix.length - 1];
        int counterI = 0;
        int counterJ = 0;
        for (int i = 0; i < distMatrix.length; i++) {
            if (i != pair[1]) {
                for (int j = 0; j < distMatrix[i].length; j++) {
                    if (i == pair[0] && j == pair[0]) {
                        safeDistMatrix[counterI][counterJ] = 0;
                    } else if (j == pair[1]) {
                        counterJ--;
                    } else if (i == pair[0]) {
                        double d = distMatrix[pair[0]][j] * cluster[pair[0]].length + distMatrix[pair[1]][j] * cluster[pair[1]].length;
                        double d1 = cluster[pair[0]].length + cluster[pair[1]].length;
                        double distance = d / d1;
                        safeDistMatrix[counterI][counterJ] = distance;
                    } else if (j == pair[0]) {
                        double d = distMatrix[i][pair[0]] * cluster[pair[0]].length + distMatrix[i][pair[1]] * cluster[pair[1]].length;
                        double d1 = cluster[pair[0]].length + cluster[pair[1]].length;
                        double distance = d / d1;
                        safeDistMatrix[counterI][counterJ] = distance;
                    } else {
                        safeDistMatrix[counterI][counterJ] = distMatrix[i][j];
                    }
                    counterJ++;
                }
                counterJ = 0;
                counterI++;
            }
        }
        return safeDistMatrix;
    }

    //erstellt einen Knoten für das Cluster
    public Node createNode(String[][] cluster, int[] pair, double height) {
        Node root = new Node();
        Node leftNode = new Node();
        Node rightNode = new Node();
        String[] left = cluster[pair[0]];
        String[] right = cluster[pair[1]];
        String sleft = "";
        for (int i = 0; i < left.length; i++) {
            sleft = sleft + left[i];
        }
        String sright = "";
        for (int i = 0; i < right.length; i++) {
            sright = sright + right[i];
        }
        leftNode.setHead(sleft);
        leftNode.hasSomething();
        rightNode.setHead(sright);
        rightNode.hasSomething();
        rightNode.setParent(root);
        leftNode.setParent(root);
        root.hasSomething();
        root.setHead(sleft + sright);
        root.setRightNode(rightNode);
        root.setLeftNode(leftNode);
        root.setHeight(height);
        Edge leftEdge = new Edge(root.getHeight(), root, leftNode);
        root.setLeftEdge(leftEdge);
        Edge rightEdge = new Edge(root.getHeight(), root, rightNode);
        root.setRightEdge(rightEdge);
        return root;
    }

    //fügt alle aktuellen Knoten zusammen
    public Node[] setNewAllNodes(Node[] allNodes, Node newRoot) {
        Node[] newAll = new Node[allNodes.length + 1];
        for (int i = 0; i < newAll.length; i++) {
            if (i < allNodes.length) {
                newAll[i] = allNodes[i];
            } else if (i == allNodes.length) {
                newAll[i] = newRoot;
            }
        }
        return newAll;
    }

    //fügt alle aktuellen Edges zusammen
    public Edge[] newEdges(Edge[] allEdges, Edge leftEdge, Edge rightEdge) {
        if (allEdges == null) {
            return new Edge[]{leftEdge, rightEdge};
        } else {
            Edge[] newEdges = new Edge[allEdges.length + 2];
            for (int i = 0; i < newEdges.length; i++) {
                if (i < allEdges.length) {
                    newEdges[i] = allEdges[i];
                } else if (i == newEdges.length - 2) {
                    newEdges[i] = leftEdge;
                } else if (i == newEdges.length - 1) {
                    newEdges[i] = rightEdge;
                }
            }
            return newEdges;
        }
    }

    //erstellt einen Array aus den gegebenen Taxen, aus diesem entsteht ein Array mit den korrespondierenden Knoten
    public Node[] allNodes(String[][] cluster) {
        Node[] allNodes = new Node[cluster.length];
        for (int i = 0; i < cluster.length; i++) {
            String s = "";
            for (int j = 0; j < cluster[i].length; j++) {
                s = s + cluster[i][j];
            }
            Node neu = new Node();
            neu.setHead(s);
            neu.setHeight(0);
            neu.hasSomething();
            allNodes[i] = neu;
        }
        return allNodes;
    }

    //erstellt den Baum aus allen Knoten
    public Node createTree(Node[] allNodes) {
        Node tree = new Node();
        for (int i = 0; i < allNodes.length; i++) {
            Node p = allNodes[i];
            if (!p.isLeaf()) {
                Node ln = p.getLeftNode();
                Node rn = p.getRightNode();
                for (int j = 0; j < allNodes.length; j++) {
                    if (ln.getHead().equals(allNodes[j].getHead())) {
                        allNodes[j].setParent(p);
                        ln.setLeftNode(allNodes[j].getLeftNode());
                        ln.setRightNode(allNodes[j].getRightNode());
                        ln.setHeight(allNodes[j].getHeight());
                    }
                    if (rn.getHead().equals(allNodes[j].getHead())) {
                        rn.setLeftNode(allNodes[j].getLeftNode());
                        rn.setRightNode(allNodes[j].getRightNode());
                        rn.setHeight(allNodes[j].getHeight());
                    }
                }
            }
        }
        for (int i = 0; i < allNodes.length; i++) {
            if (allNodes[i].getParent() == null) {
                tree = allNodes[i];
            }
        }
        return tree;
    }

    //gibt den Baum im Newick Format zurück
    public String printTree(Node tree) {
        if (tree.isEmpty()) {
            return "";
        } else if (tree.getParent() == null) {
            return "(" + printTree(tree.getRightNode()) + ":" + (tree.getHeight() - tree.getRightNode().getHeight()) + "," + printTree(tree.getLeftNode()) + ":" + (tree.getHeight() - tree.getLeftNode().getHeight()) + ");";
        } else if (tree.isLeaf()) {
            return tree.getHead();
        } else {
            return "(" + printTree(tree.getRightNode()) + ":" + (tree.getHeight() - tree.getRightNode().getHeight()) + "," + printTree(tree.getLeftNode()) + ":" + (tree.getHeight() - tree.getLeftNode().getHeight()) + ")";
        }
    }

  /*  public static void main(String[] args) throws IOException {
        UPGMA up = new UPGMA();
        Scanner input = new Scanner(System.in);
        System.out.println("Enter FileName(Example: DistanceMatrix.csv): ");
        String path = input.nextLine();

        checkDistanceMatrix check = new checkDistanceMatrix(path, true);
        if(check.getCheck().equals("true")) {
            Node tree = up.algorithm(check.getTaxa(), check.getDistanceMatrix());
            System.out.println(up.printTree(tree));
        } else {
            System.out.println(check.getCheck());
        }
    }*/
}
