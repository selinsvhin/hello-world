package model;

import javafx.scene.control.Label;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Line;
import javafx.scene.text.Font;

public class FXFraction {

    private AnchorPane pane;
    private double sizeClusterI;
    private double sizeClusterJ;
    private double distIL;
    private double distJL;

    private Label formula;
    private Label numerator;
    private Label denominator;
    private Line line;

    private Font font;

    public FXFraction(double sizeClusterI, double sizeClusterJ, double distIL, double distJL) {
        this.pane = new AnchorPane();
        this.sizeClusterI = sizeClusterI;
        this.sizeClusterJ = sizeClusterJ;
        this.distIL = distIL;
        this.distJL = distJL;

        this.formula = new Label();
        this.numerator = new Label();
        this.denominator = new Label();
        this.line = new Line();

        this.font = new Font("Arial", 15);
    }

    public void createCalc() {

        int width = 294;
        int height = 182;
        this.pane.setPrefSize(width, height);
        int startForm = 10;

        this.formula.setLayoutX(startForm);
        this.formula.setLayoutY(height / 2 - 10);
        this.formula.setText("d(k,l) = ");
        this.formula.setFont(this.font);

        double startFrac = startForm + this.formula.getText().length() * 6.8;

        this.numerator.setLayoutX(startFrac);
        this.numerator.setLayoutY(height / 2 - 20);
        this.numerator.setText(this.distIL + " * " + this.sizeClusterI + " + " + this.distJL + " * " + this.sizeClusterJ);
        this.numerator.setFont(this.font);

        double lengthNum = (this.distIL + " * " + this.sizeClusterI + " + " + this.distJL + " * " + this.sizeClusterJ).length();

        this.denominator.setLayoutX((lengthNum * 6.8) / 2 + (lengthNum * 6.8) / 4);
        this.denominator.setLayoutY(height / 2 + 1);
        this.denominator.setText(this.sizeClusterI + " + " + this.sizeClusterJ);
        this.denominator.setFont(this.font);

        this.line.setStartX(startFrac);
        this.line.setEndX(startFrac + lengthNum * 6.8);
        this.line.setStartY(height / 2);
        this.line.setEndY(height / 2);

        this.pane.getChildren().add(this.numerator);
        this.pane.getChildren().add(this.denominator);
        this.pane.getChildren().add(this.line);
        this.pane.getChildren().add(this.formula);

    }

    public AnchorPane getPane() {
        return this.pane;
    }
}
