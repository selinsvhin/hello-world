package model;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedList;

//Die Klasse hat einen String Array, der Index in diesem entspricht dem Index in der Matrix des Namens
//Außerdem einen 2d int array, in dem die distanzen gespeichert sind. Mithilfe des string arrays kann man dann auf die jeweiligen DIstanzen zugreifen
public class ReadCSV {
    // Man muss einen Array erstellen der int hat und schaut welcher Index welcher Zahl entspricht.
    private double[][] distanzmatrix;
    private String[] index;

    public ReadCSV(String path) {
        this.csvInArray(path);
    }

    //liest csv Datei in die beiden Klassenvariablen ein, eimal die Taxen(index), und die Distanzmatrix
    public void csvInArray(String path) {
        try {
            Path newPath = Path.of(path);
            LinkedList<String> lList = new LinkedList<String>(Files.readAllLines(newPath));
            this.index = new String[lList.size() - 1];
            this.distanzmatrix = new double[index.length][index.length];
            String[][] lines = new String[lList.size()][];
            int i = 0;
            while (!lList.isEmpty() && i < lines.length) {
                lines[i] = lList.getFirst().split(",");
                i++;
                lList = new LinkedList<String>(lList.subList(1, lList.size()));
            }
            for (int j = 0; j < this.index.length; j++) {
                this.index[j] = lines[0][j + 1];
            }
            for (int j = 0; j < this.distanzmatrix.length; j++) {
                for (int k = 0; k < this.distanzmatrix[j].length; k++) {
                    this.distanzmatrix[j][k] = Double.parseDouble(lines[j + 1][k + 1]);
                }
            }
        } catch (IOException e) {
            System.out.println(e);
        }
    }

    public String[] getTaxa() {
        return index;
    }

    public double[][] getDistanzmatrix() {
        return distanzmatrix;
    }

    public void setDistanzmatrix(double[][] distanzmatrix) {
        this.distanzmatrix = distanzmatrix;
    }

    public void setTaxa(String[] index) {
        this.index = index;
    }
}
