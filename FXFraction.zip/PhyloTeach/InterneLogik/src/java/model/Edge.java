package model;

public class Edge {
    private double dist;
    private Node parentnode;
    private Node childNode;

    public Edge(double dist, Node first, Node second) {
        this.dist = dist;
        this.parentnode = first;
        this.childNode = second;
    }

    public double getDist() {
        return dist;
    }

    public Node getFirst() {
        return parentnode;
    }

    public Node getChildNode() {
        return childNode;
    }

    public void setDist(double dist) {
        this.dist = dist;
    }

    public void setFirst(Node parentnode) {
        this.parentnode = parentnode;
    }

    public void setChildNode(Node childNode) {
        this.childNode = childNode;
    }
}
