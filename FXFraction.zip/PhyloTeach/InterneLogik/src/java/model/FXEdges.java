package model;

import javafx.scene.paint.Paint;
import javafx.scene.shape.Line;
import javafx.scene.text.Text;

// Repräsentiert eine Kante als Linie in FX
//Y ist die Höhe, also der Höhenunterschied zwischen einem Kindknoten und dessen Elternknoten
//X ist der halbe Abstand zum Geschwisterknoten
//Die Kante besteht also aus zwei Linien, eine die nach oben führt und eine die dann zur Mitte hinführt
public class FXEdges {
    private Line lineInHeight = new Line();
    private Line lineInWidth = new Line();
    private Node parent;
    private  Node child;
    private Text label = new Text();
    private Text leave = new Text();
    public FXEdges()
    {
    }
    public void setLeave()
    {
        if(child.isLeaf())
        {
            this.leave.setText(child.getHead());
            leave.setX(lineInWidth.getStartX() - 3);
            leave.setY(lineInHeight.getStartY()+ 14);
        }
    }

    public Text getLeave() {
        return leave;
    }

    public void setLeave(Text leave) {
        this.leave = leave;
    }

    public void setLabel()
    {
        if(parent != null) {
            double l = parent.getHeight() - child.getHeight();
            String s = Double.toString(l);
            label.setText(s);
            label.setX(lineInHeight.getStartX() + 10);
            label.setY(lineInHeight.getStartY() - ((lineInHeight.getStartY()-lineInHeight.getEndY())/2));
        }
    }
    public void setParent(Node parent) {
        this.parent = parent;
    }

    public Node getParent() {
        return parent;
    }

    public Node getChild() {
        return child;
    }

    public Text getLabel() {
        return label;
    }
    public void setLabel(Text label)
    {
        this.label = label;
    }
    public void setChild(Node child) {
        this.child = child;
    }
    public Line getLineInHeight() {
        return lineInHeight;
    }

    public void setLineInHeight(Line line) {
        this.lineInHeight = line;
    }

    public Line getLineInWidth() {
        return lineInWidth;
    }

    public void setLineInWidth(Line lineInWidth) {
        this.lineInWidth = lineInWidth;
    }

    public void setHeightLineInImage(double startX, double startY, double endX, double endY)
    {
        this.lineInHeight.setStartX(startX);
        this.lineInHeight.setEndX(endX);
        this.lineInHeight.setStartY(startY);
        this.lineInHeight.setEndY(endY);
    }
    public void setWidthLineInImage(double startX, double startY, double endX, double endY)
    {
        this.lineInWidth.setStartX(startX);
        this.lineInWidth.setEndX(endX);
        this.lineInWidth.setStartY(startY);
        this.lineInWidth.setEndY(endY);
    }
    public void setColor(Paint color)
    {
        this.lineInHeight.setStroke(color);
        this.lineInWidth.setStroke(color);
    }
    public boolean isBothLinesCorrect()
    {
        if(this.lineInHeight.getStartX() != this.lineInHeight.getEndX())
        {
            return false;
        }
        if(this.lineInWidth.getStartY() != this.lineInWidth.getEndY())
        {
            return false;
        }
        if(this.lineInHeight.getEndY() != this.lineInWidth.getStartY())
        {
            return false;
        }
        if(this.lineInHeight.getEndX() != this.lineInWidth.getStartX())
        {
            return false;
        }
        else
        {
            return true;
        }
    }
    public void setDimensions(double startX, double startY, double endX, double endY)
    {
        this.setWidthLineInImage(startX,endY,endX,endY);
        this.setHeightLineInImage(startX,startY,startX,endY);
    }
}
