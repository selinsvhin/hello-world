package view;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.SpinnerValueFactory.IntegerSpinnerValueFactory;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import model.*;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable {
    ObservableList list = FXCollections.observableArrayList();
    @FXML
    Button startProgram;
    @FXML
    Button ownMatrix;
    @FXML
    Button readCsvFile;
    @FXML
    Button submitMatrix;
    @FXML
    Spinner<Integer> myspinner = new Spinner();
    @FXML
    Button submitFile;
    @FXML
    Button changeInput;
    @FXML
    Button goToUPGMA = new Button();
    @FXML
    Button tutorial;
    @FXML
    Button next = new Button();
    @FXML
    Button goToDownload;
    @FXML
    Button goBackFromDownload;
    @FXML
    Button back = new Button();
    @FXML
    Button download = new Button();
    @FXML
    TextField csvInput = new TextField();
    @FXML
    VBox calcBox = new VBox();
    @FXML
    VBox matrixBox = new VBox();
    @FXML
    AnchorPane treeBox = new AnchorPane();
    @FXML
    Label checkCSV = new Label();
    @FXML
    Label checkMatrix = new Label();
    @FXML
    static checkDistanceMatrix matrix;
    @FXML
    AnchorPane anchor;
    @FXML
    static FXInputMatrix fxMatrix;
    @FXML
    static String CurrMatrix;
    static AnchorPane CurrCalc = new AnchorPane();
    static String CurrTree;
    static Tree upgmaTree;
    static int step;

    public Controller() {
    }

    public void initialize(URL url, ResourceBundle rb) {
        int MAX_TAXA = 10;
        int MIN_TAXA = 2;
        SpinnerValueFactory<Integer> valueFactory = new IntegerSpinnerValueFactory(MIN_TAXA, MAX_TAXA);
        valueFactory.setValue(Integer.valueOf(MIN_TAXA));
        this.myspinner.setValueFactory(valueFactory);
    }

    public void goToInputScene(ActionEvent event) throws Exception {
        Parent root = FXMLLoader.load(getClass().getResource("chooseInputScene.fxml"));
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.show();
    }

    public void goToConstructOwnMatrixScene() throws Exception {
        Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("constructOwnMatrixScene.fxml"));
        Stage window = (Stage) this.ownMatrix.getScene().getWindow();
        goToUPGMA.setDisable(true);
        window.setScene(new Scene(root));
    }

    public void submitTaxaNum(ActionEvent event) throws IOException {
        AnchorPane root = (AnchorPane) FXMLLoader.load(this.getClass().getResource("constructOwnMatrixScene.fxml"));
        Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();

        int taxaNum = this.myspinner.getValue();

        fxMatrix = new FXInputMatrix(taxaNum);
        fxMatrix.createGridPane();
        GridPane grid = fxMatrix.getGrid();

        this.anchor.getChildren().add(grid);
        root.getChildren().add(this.anchor);
        stage.setScene(new Scene(root));
        stage.show();
    }

    public void submitMatrix() throws IOException {

        if(fxMatrix != null) {
            fxMatrix.processInput();
            matrix = new checkDistanceMatrix(fxMatrix.getInput(), false);
            String Result = matrix.getCheck();
            checkMatrix.setWrapText(true);
            checkMatrix.setText(Result);
        }
    }

    public void goToReadCsvFileScene() throws Exception {
        Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("readCsvFileScene.fxml"));
        Stage window = (Stage) this.readCsvFile.getScene().getWindow();
        window.setScene(new Scene(root));
    }

    public void setOnMousePressedCSV() throws IOException {
        matrix = new checkDistanceMatrix(csvInput.getText(), true);
        String Result = matrix.getCheck();
        checkCSV.setWrapText(true);
        checkCSV.setText(Result);
    }


    public void goToUPGMAScene(ActionEvent event) throws Exception {
        if (this.matrix.getCheck().equals("true") || this.matrix.getCheck().equals("Achtung die Matrix ist nicht ultrametrisch: Der Baum wird nicht korrekt dargestellt!")) {
            this.upgmaTree = new Tree(this.matrix.getTaxa(), this.matrix.getDistanceMatrix());
            this.step = -1;
            this.nextStep(); //wird nicht angezeigt
            back.setDisable(true); //wird nicht angezeigt
            Parent root = FXMLLoader.load(getClass().getResource("UPGMAScene.fxml"));
            Stage stage = (Stage) ((javafx.scene.Node) event.getSource()).getScene().getWindow();
            Scene scene = new Scene(root);
            stage.setScene(scene);
            stage.show();

        }
    }

    public void goToTutorialScene() throws Exception {
        Parent root = (Parent) FXMLLoader.load(this.getClass().getResource("TutorialScene.fxml"));
        Stage window = (Stage) this.tutorial.getScene().getWindow();
        window.setScene(new Scene(root));
    }

    public void goToDownloadFullTreeScene() throws Exception {
        BorderPane root = FXMLLoader.load(this.getClass().getResource("DownloadFullTreeScene.fxml"));
        Pane placeForTree = new Pane();
        root.setCenter(placeForTree);

        Node root2 = this.upgmaTree.getRoot();
        LayoutAlgorithm la = new LayoutAlgorithm(500, 500, root2);
        la.analyzeTree(root2);
        FXEdges[] edges = la.treeInImage();

        for (int i = 0; i < edges.length; i++) {
            if (edges[i].isBothLinesCorrect()) {
                placeForTree.getChildren().add(edges[i].getLineInWidth());
                placeForTree.getChildren().add(edges[i].getLineInHeight());
                edges[i].setLabel();
                edges[i].setLeave();
                if (edges[i].getParent() != null) {
                    placeForTree.getChildren().add(edges[i].getLabel());
                }
                if (edges[i].getChild().isLeaf()) {
                    placeForTree.getChildren().add(edges[i].getLeave());
                }
            }
        }
        Stage window = (Stage) this.goToDownload.getScene().getWindow();
        window.setScene(new Scene(root));
    }

    public void nextStep() {
        if (this.step < this.upgmaTree.getMatrixList().size() - 1 && this.step < this.upgmaTree.getCalcList().size() - 1 && this.step < this.upgmaTree.getTreeList().size() - 1) {
            this.step++;
            if (step == this.upgmaTree.getMatrixList().size() - 1) {
                next.setDisable(true);
            } else {
                next.setDisable(false);
            }
            if(step!=0){
                back.setDisable(false);
            }
            this.CurrMatrix = this.upgmaTree.getMatrixList().get(this.step);
            matrixBox.getChildren().clear();
            matrixBox.getChildren().add(new Label(CurrMatrix));

            this.CurrCalc = this.upgmaTree.getCalcList().get(this.step);
            calcBox.getChildren().clear();
            calcBox.getChildren().add(CurrCalc);

            this.CurrTree = this.upgmaTree.getTreeList().get(this.step);
            treeBox.getChildren().clear();
            treeBox.getChildren().add(new Label(CurrTree));
        }
    }

    public void backStep() {
        if (this.step > 0 && this.step > 0 && this.step > 0) {
            this.step--;
            if (step == 0) {
                back.setDisable(true);
            } else {
                back.setDisable(false);
            }
            if(step!= this.upgmaTree.getMatrixList().size() - 1){
                next.setDisable(false);
            }
            this.CurrMatrix = this.upgmaTree.getMatrixList().get(this.step);
            matrixBox.getChildren().clear();
            matrixBox.getChildren().add(new Label(CurrMatrix));

            this.CurrCalc = this.upgmaTree.getCalcList().get(this.step);
            calcBox.getChildren().clear();
            calcBox.getChildren().add(CurrCalc);

            this.CurrTree = this.upgmaTree.getTreeList().get(this.step);
            treeBox.getChildren().clear();
            treeBox.getChildren().add(new Label(CurrTree));
        }
    }
}

