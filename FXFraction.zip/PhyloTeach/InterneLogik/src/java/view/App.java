package view;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class App extends Application {
    @Override
    public void start(Stage primarystage) throws Exception {
        Parent root = FXMLLoader.load(this.getClass().getResource("startscene.fxml"));
        primarystage.setTitle("Welcome: Let´s create an UPGMA Tree");
        primarystage.setScene(new Scene(root));
        primarystage.setResizable(false);
        primarystage.show();
    }
}
